<?php

require_once 'app/classes/HelloWorld.php';

$HelloWorld = new HelloWorld();
$HelloWorld->index();