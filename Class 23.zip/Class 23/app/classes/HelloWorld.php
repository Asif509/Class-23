<?php

namespace App\classes;

class HelloWorld
{
  public function index()
  {
      echo 'Hello Bitm';
  }
}